# 🚀 Write It Great Proposal Evaluation System
# Complete Deployment Guide for GitHub & Heroku

## ✅ Pre-Deployment Checklist

Your system is **READY** for deployment. Here's what's included:

| Component | Status | Description |
|-----------|--------|-------------|
| `app.py` | ✅ Ready | Main Flask application |
| `evaluate.py` | ✅ Ready | OpenAI evaluation engine |
| `email_service.py` | ✅ Ready | Mailchimp team notifications |
| `report_generator.py` | ✅ Ready | PDF report generation |
| `templates/` | ✅ Ready | HTML pages (form, results, error) |
| `static/` | ✅ Ready | CSS, JS, and logo |
| `Procfile` | ✅ Ready | Heroku configuration |
| `requirements.txt` | ✅ Ready | Python dependencies |
| `runtime.txt` | ✅ Ready | Python version (3.11.7) |

---

# PART 1: PREPARE YOUR INFORMATION

Before we start, gather these items:

## 1.1 OpenAI API Key (REQUIRED)
You already have this:
```
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
```

## 1.2 Team Email (REQUIRED)
Which email should receive notifications when proposals are submitted?
Example: `andy@writeitgreat.com`

## 1.3 Mailchimp Transactional API Key (OPTIONAL - for email)
If you want email notifications:
1. Go to mailchimp.com → Transactional (Mandrill)
2. Settings → SMTP & API Info → API Key

If you don't have this, the system will still work - you just won't get email notifications (you can add this later).

---

# PART 2: GITHUB SETUP

## Step 2.1: Download the Files

First, download the corrected zip file I've provided:
- **writeitgreat-proposal-system-ready.zip**

Unzip it on your computer. You should see a folder called `writeitgreat-proposal-system` with these files inside.

## Step 2.2: Log into GitHub

1. Go to **github.com**
2. Sign in with your credentials
3. Find the `proposal-evaluation` repository your boss created

## Step 2.3: Upload Files to GitHub

**Option A: Using GitHub Web Interface (Easiest)**

1. Open your `proposal-evaluation` repository
2. Click the **"Add file"** button (green button)
3. Click **"Upload files"**
4. Drag ALL the files from your unzipped folder into the upload area:
   - app.py
   - evaluate.py
   - email_service.py
   - report_generator.py
   - Procfile
   - requirements.txt
   - runtime.txt
   - .gitignore
   - .env.example
   - README.md
   - templates/ folder (drag the whole folder)
   - static/ folder (drag the whole folder)
5. At the bottom, type a commit message: `Initial upload of proposal evaluation system`
6. Click **"Commit changes"**

**Note:** If GitHub asks about "main" vs "master" branch, just use whatever is already there.

## Step 2.4: Verify Upload

After uploading, your repository should look like this:
```
proposal-evaluation/
├── .gitignore
├── .env.example
├── Procfile
├── README.md
├── app.py
├── email_service.py
├── evaluate.py
├── report_generator.py
├── requirements.txt
├── runtime.txt
├── static/
│   ├── css/
│   │   └── style.css
│   ├── images/
│   │   └── logo.webp
│   └── js/
│       └── main.js
└── templates/
    ├── error.html
    ├── index.html
    └── results.html
```

---

# PART 3: HEROKU SETUP

## Step 3.1: Log into Heroku

1. Go to **heroku.com**
2. Sign in with your credentials
3. You should see the Heroku Dashboard

## Step 3.2: Create New App (if not already created)

If your boss already created an app called `proposal-evaluation`:
- Click on it in your dashboard
- Skip to Step 3.3

If you need to create a new app:
1. Click **"New"** (top right)
2. Click **"Create new app"**
3. Enter app name: `writeitgreat-proposals` (or similar)
4. Choose region: **United States**
5. Click **"Create app"**

## Step 3.3: Connect Heroku to GitHub

1. In your Heroku app dashboard, click the **"Deploy"** tab
2. Under "Deployment method", click **"GitHub"**
3. Click **"Connect to GitHub"** (you may need to authorize)
4. Search for your repository: `proposal-evaluation`
5. Click **"Connect"**

## Step 3.4: Configure Environment Variables

This is the most important step - setting your API keys securely.

1. Click the **"Settings"** tab
2. Scroll down to **"Config Vars"**
3. Click **"Reveal Config Vars"**
4. Add these variables one by one (click "Add" after each):

| KEY | VALUE |
|-----|-------|
| `OPENAI_API_KEY` | `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` |
| `SECRET_KEY` | `wig-proposal-secret-2024-change-this` |
| `TEAM_EMAIL` | `andy@writeitgreat.com` *(change to your team email)* |
| `FLASK_DEBUG` | `false` |

**If you have Mailchimp, also add:**
| KEY | VALUE |
|-----|-------|
| `MAILCHIMP_API_KEY` | *(your Mandrill/Transactional API key)* |
| `MAILCHIMP_FROM_EMAIL` | `proposals@writeitgreat.com` |
| `MAILCHIMP_FROM_NAME` | `Write It Great` |

## Step 3.5: Deploy the App

1. Go back to the **"Deploy"** tab
2. Scroll down to **"Manual deploy"**
3. Make sure the branch is `main` (or `master`)
4. Click **"Deploy Branch"**
5. Wait for the build to complete (this takes 2-3 minutes)
6. You should see: **"Your app was successfully deployed"**

## Step 3.6: Open Your App

1. Click **"Open app"** (top right of the page)
2. Your proposal evaluation system should now be live!
3. The URL will be something like: `https://proposal-evaluation.herokuapp.com`

---

# PART 4: TEST YOUR SYSTEM

## Step 4.1: Basic Test

1. Open your Heroku app URL
2. You should see the "Book Proposal Evaluation" form
3. Fill in test data:
   - Name: Test Author
   - Email: your-email@example.com
   - Book Title: Test Book
   - Select "Full Proposal"
   - Upload any PDF (even a random document for testing)
   - Check both agreement boxes
4. Click **"Submit for Evaluation"**
5. Wait 30-60 seconds for the AI evaluation
6. You should see results with:
   - Tier rating (A, B, C, or D)
   - Overall score
   - Detailed feedback
   - Download PDF button

## Step 4.2: Check Email Notifications

If you configured Mailchimp:
- Check the TEAM_EMAIL inbox
- You should receive an email with the evaluation summary

If you didn't configure Mailchimp:
- That's fine! The system still works
- Check Heroku logs to see the notification: Go to **"More"** → **"View logs"**

---

# PART 5: ENABLE AUTOMATIC DEPLOYS (Optional)

This makes future updates automatic:

1. In Heroku, go to **"Deploy"** tab
2. Scroll to **"Automatic deploys"**
3. Click **"Enable Automatic Deploys"**

Now whenever you update files in GitHub, Heroku will automatically redeploy.

---

# TROUBLESHOOTING

## "Application Error" when opening the site
1. Go to Heroku → **"More"** → **"View logs"**
2. Look for red error messages
3. Common issues:
   - Missing Config Var (add in Settings → Config Vars)
   - Typo in a file (check GitHub and re-upload)

## "H10 - App crashed"
- Usually means a Python error
- Check logs for the specific error
- Most common: missing OPENAI_API_KEY

## PDF upload fails
- Make sure the PDF is not encrypted/password-protected
- PDF must be text-based (not a scanned image)

## No email notifications
- Check MAILCHIMP_API_KEY is correct
- Check TEAM_EMAIL is correct
- Mailchimp requires verified sender domains

---

# YOUR LIVE URLS

After deployment, your URLs will be:

- **Main Form:** `https://[your-app-name].herokuapp.com/`
- **Health Check:** `https://[your-app-name].herokuapp.com/health`
- **Results:** `https://[your-app-name].herokuapp.com/results/[submission-id]`

---

# NEED HELP?

If you get stuck at any step:
1. Take a screenshot of the error
2. Copy any error messages from Heroku logs
3. Let me know which step you're on

I'm here to help you get this deployed! 🚀
